NOTATNIK - INSTRUKCJA INSTALACJI (GitHub Pages)

Co jest w paczce: index.html (aplikacja), manifest.webmanifest, sw.js, icon-192.png, icon-512.png.
Wszystkie 5 plikow musi trafic na GitHuba. README.txt nie jest potrzebny.

CZESC 1. WRZUCENIE NA GITHUB
1. Rozpakuj ZIP-a (aplikacja Pliki > przytrzymaj plik > Wyodrebnij). Wrzucasz pliki z srodka, nie samego ZIP-a.
2. Wejdz na github.com > Sign up. Podaj e-mail, haslo i nazwe uzytkownika (np. anna123). Potwierdz e-mail kodem.
3. Po zalogowaniu kliknij "+" u gory > New repository.
4. Repository name: notatnik. Zaznacz Public (Private nie dziala za darmo z Pages).
   Zaznacz "Add a README file". Kliknij Create repository.
5. W repozytorium: Add file > Upload files. Kliknij "choose your files" i zaznacz 5 plikow
   (index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png).
6. Zjedz na dol i kliknij Commit changes. Poczekaj, az pliki sie pojawia na liscie.

CZESC 2. WLACZENIE STRONY
7. Zakladka Settings (jesli nie widac, wlacz w przegladarce "Wersja na komputer").
8. W menu po lewej: Pages.
9. Build and deployment > Source: Deploy from a branch. Branch: main, folder: / (root). Save.
10. Odczekaj 1-3 minuty i odswiez strone. Na gorze pojawi sie adres:
    https://TWOJANAZWA.github.io/notatnik/

CZESC 3. INSTALACJA NA TABLECIE
11. Otworz ten adres na tablecie w przegladarce (najlepiej Chrome, jesli masz; w przegladarce Huawei tez zadziala).
12. Menu przegladarki (trzy kropki) > "Dodaj do ekranu glownego" albo "Zainstaluj aplikacje".
13. Uruchom raz z ikony, gdy masz internet. Potem dziala tez bez internetu.

AKTUALIZACJA
Wejdz do repozytorium > Add file > Upload files i wrzuc nowy index.html (nadpisze stary).
Otworz aplikacje z internetem 2 razy, aby pobrala nowa wersje.

WAZNE
- Repozytorium jest publiczne: widac kod aplikacji, ale NIE widac Twoich notatek. Notatki sa tylko w pamieci przegladarki na tablecie.
- Wyczyszczenie danych przegladarki usunie notatki. Wazne rzeczy eksportuj (ikona udostepniania u gory).
